function verReseña() {
    window.location.href = "infoResena";
}