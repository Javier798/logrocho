<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../View/styles/error500.css" rel="stylesheet">

    <link rel="stylesheet" href="/dwes/PruebaProyecto/View/styles/menu.css">
    <title>Document</title>
</head>

<body class="loading">
    <nav id="nav">
        <div>
            <a href="listadoBares"> Logrocho</a>
        </div>
        <div>
        </div>

    </nav>
    <h1>500</h1>
    <h2>Internal server error <b>:(</b></h2>
    <div class="gears">
        <div class="gear one">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <div class="gear two">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
        <div class="gear three">
            <div class="bar"></div>
            <div class="bar"></div>
            <div class="bar"></div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
    <script src="../View/js/error500.js" type="text/javascript"></script>
</body>

</html>