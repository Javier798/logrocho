<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/dwes/PruebaProyecto/View/styles/Error404.css">
    <link rel="stylesheet" href="/dwes/PruebaProyecto//View/styles/style.css">
    <link rel="stylesheet" href="/dwes/PruebaProyecto//View/styles/menu.css">
    <title>Document</title>
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
        <div>
            <a href="listadoBares"> Logrocho</a>
        </div>
        <div>
        </div>

    </nav>
<div class="number">404</div>
<div class="text"><span>Ooops...</span><br>pagina no encontrada</div>
<a class="me" href="https://codepen.io/uzcho_/pens/popular/?grid_type=list" target="_blank"></a>
</body>
</html>